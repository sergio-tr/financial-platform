// candidate-b/src/feature-store.ts
import { computed } from "@angular/core";
import { patchState, signalState } from "@ngrx/signals";
var EMPTY_PREF = { effectiveValue: "comfortable" };
var NgrxSignalsFeatureStore = class {
  constructor(realtime) {
    this.realtime = realtime;
    this.state = signalState({
      session: "LOGGED_OUT",
      connection: "DISCONNECTED",
      snapshot: null,
      preference: { ...EMPTY_PREF },
      lastAppliedSequence: null,
      pendingGap: null,
      subscriptionGeneration: 0,
      sensitiveCleared: true,
      preferenceBaseline: EMPTY_PREF.effectiveValue
    });
    this.subDispose = null;
    this.appliedSequences = /* @__PURE__ */ new Set();
    this.view = computed(() => {
      const s = this.state;
      const snap = s.snapshot();
      const conn = s.connection();
      const last = s.lastAppliedSequence();
      const pref = s.preference();
      const gap = s.pendingGap();
      const derivedLabel = [
        s.session(),
        conn,
        snap ? `r${snap.revision}@${snap.streamSequence}` : "no-snap",
        `fin=${snap?.portfolioSummarySynthetic ?? "CLEARED"}`,
        `pref=${pref.effectiveValue}${pref.pendingMutationId ? `(pending:${pref.pendingMutationId})` : ""}`,
        gap ? `gap:${gap.expected}->${gap.observed}` : "gap:none",
        `last=${last ?? "null"}`
      ].join("|");
      return {
        session: s.session(),
        connection: conn,
        snapshot: snap,
        preference: pref,
        lastAppliedSequence: last,
        pendingGap: gap,
        subscriptionGeneration: s.subscriptionGeneration(),
        derivedLabel,
        sensitiveCleared: s.sensitiveCleared()
      };
    });
    this.portfolioDisplay = computed(() => this.state.snapshot()?.portfolioSummarySynthetic ?? null);
    this.isResyncRequired = computed(() => this.state.connection() === "RESYNC_REQUIRED");
    this.hasPendingPreference = computed(() => !!this.state.preference().pendingMutationId);
  }
  static {
    this.MUTATION_ENTRY_POINTS = [
      "bootstrapAuthenticated",
      "applyAuthoritativeSnapshot",
      "handleRealtimeEvent",
      "beginRealtimeSubscribe",
      "markDisconnected",
      "beginReconnect",
      "logout",
      "requestPreferenceOptimistic",
      "acceptPreference",
      "rejectPreference"
    ];
  }
  bootstrapAuthenticated() {
    patchState(this.state, {
      session: "AUTHENTICATED",
      sensitiveCleared: false,
      connection: "DISCONNECTED"
    });
  }
  applyAuthoritativeSnapshot(snap) {
    if (this.state.session() !== "AUTHENTICATED") return;
    this.appliedSequences.clear();
    this.appliedSequences.add(snap.streamSequence);
    const conn = this.state.connection();
    patchState(this.state, {
      snapshot: { ...snap },
      lastAppliedSequence: snap.streamSequence,
      pendingGap: null,
      sensitiveCleared: false,
      connection: conn === "RESYNC_REQUIRED" || conn === "CONNECTING" ? "LIVE" : conn
    });
  }
  beginRealtimeSubscribe() {
    if (this.state.session() !== "AUTHENTICATED") return;
    const gen = this.state.subscriptionGeneration() + 1;
    patchState(this.state, { subscriptionGeneration: gen, connection: "CONNECTING" });
    this.disposeSub();
    const from = this.state.lastAppliedSequence() ?? 0;
    const handle = this.realtime.subscribe(from, gen, {
      onEvent: (event, generation) => this.handleRealtimeEvent(event, generation),
      onDisconnect: (generation) => {
        if (generation !== this.state.subscriptionGeneration()) return;
        patchState(this.state, { connection: "DISCONNECTED" });
      }
    });
    this.subDispose = handle.dispose;
    patchState(this.state, { connection: "LIVE" });
  }
  handleRealtimeEvent(event, generation) {
    if (this.state.session() !== "AUTHENTICATED") return;
    if (generation !== this.state.subscriptionGeneration()) return;
    if (this.state.connection() === "RESYNC_REQUIRED") return;
    const last = this.state.lastAppliedSequence();
    if (last === null) return;
    if (this.appliedSequences.has(event.sequence) || event.sequence <= last) {
      return;
    }
    const expected = last + 1;
    if (event.sequence !== expected) {
      patchState(this.state, {
        pendingGap: { expected, observed: event.sequence },
        connection: "RESYNC_REQUIRED"
      });
      return;
    }
    const current = this.state.snapshot();
    if (!current) return;
    this.appliedSequences.add(event.sequence);
    patchState(this.state, {
      snapshot: {
        ...current,
        streamSequence: event.sequence,
        portfolioSummarySynthetic: event.payload.portfolioSummarySynthetic
      },
      lastAppliedSequence: event.sequence
    });
  }
  markDisconnected() {
    this.realtime.disconnect();
    this.disposeSub();
    if (this.state.session() === "AUTHENTICATED") {
      patchState(this.state, { connection: "DISCONNECTED" });
    }
  }
  beginReconnect() {
    if (this.state.session() !== "AUTHENTICATED") return;
    patchState(this.state, { connection: "RECONNECTING" });
    this.beginRealtimeSubscribe();
  }
  logout() {
    this.disposeSub();
    this.realtime.disconnect();
    this.appliedSequences.clear();
    patchState(this.state, {
      session: "LOGGED_OUT",
      connection: "DISCONNECTED",
      snapshot: null,
      lastAppliedSequence: null,
      pendingGap: null,
      preference: { ...EMPTY_PREF },
      preferenceBaseline: EMPTY_PREF.effectiveValue,
      sensitiveCleared: true,
      subscriptionGeneration: this.state.subscriptionGeneration() + 1
    });
  }
  requestPreferenceOptimistic(mutationId, value) {
    if (this.state.session() !== "AUTHENTICATED") return;
    const current = this.state.preference();
    patchState(this.state, {
      preferenceBaseline: current.effectiveValue,
      preference: { effectiveValue: value, pendingMutationId: mutationId }
    });
  }
  acceptPreference(mutationId) {
    const p = this.state.preference();
    if (p.pendingMutationId !== mutationId) return;
    patchState(this.state, {
      preference: { effectiveValue: p.effectiveValue },
      preferenceBaseline: p.effectiveValue
    });
  }
  rejectPreference(mutationId) {
    const p = this.state.preference();
    if (p.pendingMutationId !== mutationId) return;
    patchState(this.state, {
      preference: { effectiveValue: this.state.preferenceBaseline() }
    });
  }
  get storageApiTouchCount() {
    return 0;
  }
  disposeSub() {
    if (this.subDispose) {
      this.subDispose();
      this.subDispose = null;
    }
  }
};
export {
  NgrxSignalsFeatureStore
};
