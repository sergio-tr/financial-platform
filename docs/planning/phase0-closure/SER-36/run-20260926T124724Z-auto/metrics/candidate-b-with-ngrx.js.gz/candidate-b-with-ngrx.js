// candidate-b/src/feature-store.ts
import { computed as computed2 } from "@angular/core";

// candidate-b/node_modules/.pnpm/@ngrx+signals@22.0.1_@angular+core@22.2.0_@angular+compiler@22.2.0_rxjs@7.8.2__rxjs@7.8.2/node_modules/@ngrx/signals/fesm2022/ngrx-signals.mjs
import * as i0 from "@angular/core";
import { untracked, isSignal, computed, assertInInjectionContext, inject, Injector, effect, DestroyRef, signal, Injectable, linkedSignal } from "@angular/core";
var DEEP_SIGNAL = /* @__PURE__ */ Symbol(typeof ngDevMode !== "undefined" && ngDevMode ? "DEEP_SIGNAL" : "");
function toDeepSignal(signal2) {
  return new Proxy(signal2, {
    has(target, prop) {
      return !!this.get(target, prop, void 0);
    },
    get(target, prop) {
      const value = untracked(target);
      if (!isRecord(value) || !(prop in value)) {
        if (isSignal(target[prop]) && target[prop][DEEP_SIGNAL]) {
          delete target[prop];
        }
        return target[prop];
      }
      if (!isSignal(target[prop])) {
        Object.defineProperty(target, prop, {
          value: computed(() => target()[prop]),
          configurable: true
        });
        target[prop][DEEP_SIGNAL] = true;
      }
      return toDeepSignal(target[prop]);
    }
  });
}
var nonRecords = [
  WeakSet,
  WeakMap,
  Promise,
  Date,
  Error,
  RegExp,
  ArrayBuffer,
  DataView,
  Function
];
function isRecord(value) {
  if (value === null || typeof value !== "object" || isIterable(value)) {
    return false;
  }
  let proto = Object.getPrototypeOf(value);
  if (proto === Object.prototype) {
    return true;
  }
  while (proto && proto !== Object.prototype) {
    if (nonRecords.includes(proto.constructor)) {
      return false;
    }
    proto = Object.getPrototypeOf(proto);
  }
  return proto === Object.prototype;
}
function isIterable(value) {
  return typeof value?.[Symbol.iterator] === "function";
}
var STATE_WATCHERS = /* @__PURE__ */ new WeakMap();
var STATE_SOURCE = /* @__PURE__ */ Symbol(typeof ngDevMode !== "undefined" && ngDevMode ? "STATE_SOURCE" : "");
function patchState(stateSource, ...updaters) {
  const currentState = untracked(() => getState(stateSource));
  const newState = updaters.reduce((nextState, updater) => ({
    ...nextState,
    ...typeof updater === "function" ? updater(nextState) : updater
  }), currentState);
  const signals = stateSource[STATE_SOURCE];
  const stateKeys = Reflect.ownKeys(stateSource[STATE_SOURCE]);
  for (const key of Reflect.ownKeys(newState)) {
    if (stateKeys.includes(key)) {
      const signalKey = key;
      if (currentState[signalKey] !== newState[signalKey]) {
        signals[signalKey].set(newState[signalKey]);
      }
    } else if (typeof ngDevMode !== "undefined" && ngDevMode) {
      console.warn(`@ngrx/signals: patchState was called with an unknown state slice '${String(key)}'.`, "Ensure that all state properties are explicitly defined in the initial state.", "Updates to properties not present in the initial state will be ignored.");
    }
  }
  notifyWatchers(stateSource);
}
function getState(stateSource) {
  const signals = stateSource[STATE_SOURCE];
  return Reflect.ownKeys(stateSource[STATE_SOURCE]).reduce((state, key) => {
    const value = signals[key]();
    return {
      ...state,
      [key]: value
    };
  }, {});
}
function getWatchers(stateSource) {
  return STATE_WATCHERS.get(stateSource[STATE_SOURCE]) || [];
}
function notifyWatchers(stateSource) {
  const watchers = getWatchers(stateSource);
  for (const watcher of watchers) {
    executeWatcher(stateSource, watcher);
  }
}
function executeWatcher(stateSource, stateWatcher) {
  untracked(() => {
    const state = getState(stateSource);
    stateWatcher(state);
  });
}
function signalState(initialState) {
  const stateKeys = Reflect.ownKeys(initialState);
  const stateSource = stateKeys.reduce((signalsDict, key) => ({
    ...signalsDict,
    [key]: signal(initialState[key])
  }), {});
  const signalState2 = computed(
    () => stateKeys.reduce((state, key) => ({ ...state, [key]: stateSource[key]() }), {}),
    ...ngDevMode ? [{ debugName: "signalState" }] : (
      /* istanbul ignore next */
      []
    )
  );
  Object.defineProperty(signalState2, STATE_SOURCE, {
    value: stateSource
  });
  for (const key of stateKeys) {
    Object.defineProperty(signalState2, key, {
      value: toDeepSignal(stateSource[key])
    });
  }
  return signalState2;
}

// candidate-b/src/feature-store.ts
var EMPTY_PREF = { effectiveValue: "comfortable" };
var NgrxSignalsFeatureStore = class {
  constructor(realtime) {
    this.realtime = realtime;
    this.state = signalState({
      session: "LOGGED_OUT",
      connection: "DISCONNECTED",
      snapshot: null,
      preference: { ...EMPTY_PREF },
      lastAppliedSequence: null,
      pendingGap: null,
      subscriptionGeneration: 0,
      sensitiveCleared: true,
      preferenceBaseline: EMPTY_PREF.effectiveValue
    });
    this.subDispose = null;
    this.appliedSequences = /* @__PURE__ */ new Set();
    this.view = computed2(() => {
      const s = this.state;
      const snap = s.snapshot();
      const conn = s.connection();
      const last = s.lastAppliedSequence();
      const pref = s.preference();
      const gap = s.pendingGap();
      const derivedLabel = [
        s.session(),
        conn,
        snap ? `r${snap.revision}@${snap.streamSequence}` : "no-snap",
        `fin=${snap?.portfolioSummarySynthetic ?? "CLEARED"}`,
        `pref=${pref.effectiveValue}${pref.pendingMutationId ? `(pending:${pref.pendingMutationId})` : ""}`,
        gap ? `gap:${gap.expected}->${gap.observed}` : "gap:none",
        `last=${last ?? "null"}`
      ].join("|");
      return {
        session: s.session(),
        connection: conn,
        snapshot: snap,
        preference: pref,
        lastAppliedSequence: last,
        pendingGap: gap,
        subscriptionGeneration: s.subscriptionGeneration(),
        derivedLabel,
        sensitiveCleared: s.sensitiveCleared()
      };
    });
    this.portfolioDisplay = computed2(() => this.state.snapshot()?.portfolioSummarySynthetic ?? null);
    this.isResyncRequired = computed2(() => this.state.connection() === "RESYNC_REQUIRED");
    this.hasPendingPreference = computed2(() => !!this.state.preference().pendingMutationId);
  }
  static {
    this.MUTATION_ENTRY_POINTS = [
      "bootstrapAuthenticated",
      "applyAuthoritativeSnapshot",
      "handleRealtimeEvent",
      "beginRealtimeSubscribe",
      "markDisconnected",
      "beginReconnect",
      "logout",
      "requestPreferenceOptimistic",
      "acceptPreference",
      "rejectPreference"
    ];
  }
  bootstrapAuthenticated() {
    patchState(this.state, {
      session: "AUTHENTICATED",
      sensitiveCleared: false,
      connection: "DISCONNECTED"
    });
  }
  applyAuthoritativeSnapshot(snap) {
    if (this.state.session() !== "AUTHENTICATED") return;
    this.appliedSequences.clear();
    this.appliedSequences.add(snap.streamSequence);
    const conn = this.state.connection();
    patchState(this.state, {
      snapshot: { ...snap },
      lastAppliedSequence: snap.streamSequence,
      pendingGap: null,
      sensitiveCleared: false,
      connection: conn === "RESYNC_REQUIRED" || conn === "CONNECTING" ? "LIVE" : conn
    });
  }
  beginRealtimeSubscribe() {
    if (this.state.session() !== "AUTHENTICATED") return;
    const gen = this.state.subscriptionGeneration() + 1;
    patchState(this.state, { subscriptionGeneration: gen, connection: "CONNECTING" });
    this.disposeSub();
    const from = this.state.lastAppliedSequence() ?? 0;
    const handle = this.realtime.subscribe(from, gen, {
      onEvent: (event, generation) => this.handleRealtimeEvent(event, generation),
      onDisconnect: (generation) => {
        if (generation !== this.state.subscriptionGeneration()) return;
        patchState(this.state, { connection: "DISCONNECTED" });
      }
    });
    this.subDispose = handle.dispose;
    patchState(this.state, { connection: "LIVE" });
  }
  handleRealtimeEvent(event, generation) {
    if (this.state.session() !== "AUTHENTICATED") return;
    if (generation !== this.state.subscriptionGeneration()) return;
    if (this.state.connection() === "RESYNC_REQUIRED") return;
    const last = this.state.lastAppliedSequence();
    if (last === null) return;
    if (this.appliedSequences.has(event.sequence) || event.sequence <= last) {
      return;
    }
    const expected = last + 1;
    if (event.sequence !== expected) {
      patchState(this.state, {
        pendingGap: { expected, observed: event.sequence },
        connection: "RESYNC_REQUIRED"
      });
      return;
    }
    const current = this.state.snapshot();
    if (!current) return;
    this.appliedSequences.add(event.sequence);
    patchState(this.state, {
      snapshot: {
        ...current,
        streamSequence: event.sequence,
        portfolioSummarySynthetic: event.payload.portfolioSummarySynthetic
      },
      lastAppliedSequence: event.sequence
    });
  }
  markDisconnected() {
    this.realtime.disconnect();
    this.disposeSub();
    if (this.state.session() === "AUTHENTICATED") {
      patchState(this.state, { connection: "DISCONNECTED" });
    }
  }
  beginReconnect() {
    if (this.state.session() !== "AUTHENTICATED") return;
    patchState(this.state, { connection: "RECONNECTING" });
    this.beginRealtimeSubscribe();
  }
  logout() {
    this.disposeSub();
    this.realtime.disconnect();
    this.appliedSequences.clear();
    patchState(this.state, {
      session: "LOGGED_OUT",
      connection: "DISCONNECTED",
      snapshot: null,
      lastAppliedSequence: null,
      pendingGap: null,
      preference: { ...EMPTY_PREF },
      preferenceBaseline: EMPTY_PREF.effectiveValue,
      sensitiveCleared: true,
      subscriptionGeneration: this.state.subscriptionGeneration() + 1
    });
  }
  requestPreferenceOptimistic(mutationId, value) {
    if (this.state.session() !== "AUTHENTICATED") return;
    const current = this.state.preference();
    patchState(this.state, {
      preferenceBaseline: current.effectiveValue,
      preference: { effectiveValue: value, pendingMutationId: mutationId }
    });
  }
  acceptPreference(mutationId) {
    const p = this.state.preference();
    if (p.pendingMutationId !== mutationId) return;
    patchState(this.state, {
      preference: { effectiveValue: p.effectiveValue },
      preferenceBaseline: p.effectiveValue
    });
  }
  rejectPreference(mutationId) {
    const p = this.state.preference();
    if (p.pendingMutationId !== mutationId) return;
    patchState(this.state, {
      preference: { effectiveValue: this.state.preferenceBaseline() }
    });
  }
  get storageApiTouchCount() {
    return 0;
  }
  disposeSub() {
    if (this.subDispose) {
      this.subDispose();
      this.subDispose = null;
    }
  }
};
export {
  NgrxSignalsFeatureStore
};
