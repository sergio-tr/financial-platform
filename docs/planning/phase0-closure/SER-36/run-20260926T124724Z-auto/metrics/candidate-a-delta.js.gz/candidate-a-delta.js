// candidate-a/src/feature-store.ts
import { computed, signal } from "@angular/core";
var EMPTY_PREF = { effectiveValue: "comfortable" };
var SignalsFeatureStore = class {
  constructor(realtime) {
    this.realtime = realtime;
    this.session = signal("LOGGED_OUT");
    this.connection = signal("DISCONNECTED");
    this.snapshot = signal(null);
    this.preference = signal({ ...EMPTY_PREF });
    this.lastAppliedSequence = signal(null);
    this.pendingGap = signal(null);
    this.subscriptionGeneration = signal(0);
    this.sensitiveCleared = signal(true);
    this.preferenceBaseline = signal(EMPTY_PREF.effectiveValue);
    this.subDispose = null;
    this.appliedSequences = /* @__PURE__ */ new Set();
    this.view = computed(() => {
      const snap = this.snapshot();
      const conn = this.connection();
      const last = this.lastAppliedSequence();
      const pref = this.preference();
      const gap = this.pendingGap();
      const derivedLabel = [
        this.session(),
        conn,
        snap ? `r${snap.revision}@${snap.streamSequence}` : "no-snap",
        `fin=${snap?.portfolioSummarySynthetic ?? "CLEARED"}`,
        `pref=${pref.effectiveValue}${pref.pendingMutationId ? `(pending:${pref.pendingMutationId})` : ""}`,
        gap ? `gap:${gap.expected}->${gap.observed}` : "gap:none",
        `last=${last ?? "null"}`
      ].join("|");
      return {
        session: this.session(),
        connection: conn,
        snapshot: snap,
        preference: pref,
        lastAppliedSequence: last,
        pendingGap: gap,
        subscriptionGeneration: this.subscriptionGeneration(),
        derivedLabel,
        sensitiveCleared: this.sensitiveCleared()
      };
    });
    /** Derived selectors recompute deterministically from owned state. */
    this.portfolioDisplay = computed(() => this.snapshot()?.portfolioSummarySynthetic ?? null);
    this.isResyncRequired = computed(() => this.connection() === "RESYNC_REQUIRED");
    this.hasPendingPreference = computed(() => !!this.preference().pendingMutationId);
  }
  static {
    this.MUTATION_ENTRY_POINTS = [
      "bootstrapAuthenticated",
      "applyAuthoritativeSnapshot",
      "handleRealtimeEvent",
      "beginRealtimeSubscribe",
      "markDisconnected",
      "beginReconnect",
      "logout",
      "requestPreferenceOptimistic",
      "acceptPreference",
      "rejectPreference"
    ];
  }
  bootstrapAuthenticated() {
    this.session.set("AUTHENTICATED");
    this.sensitiveCleared.set(false);
    this.connection.set("DISCONNECTED");
  }
  applyAuthoritativeSnapshot(snap) {
    if (this.session() !== "AUTHENTICATED") return;
    this.snapshot.set({ ...snap });
    this.lastAppliedSequence.set(snap.streamSequence);
    this.appliedSequences.clear();
    this.appliedSequences.add(snap.streamSequence);
    this.pendingGap.set(null);
    this.sensitiveCleared.set(false);
    if (this.connection() === "RESYNC_REQUIRED" || this.connection() === "CONNECTING") {
      this.connection.set("LIVE");
    }
  }
  beginRealtimeSubscribe() {
    if (this.session() !== "AUTHENTICATED") return;
    const gen = this.subscriptionGeneration() + 1;
    this.subscriptionGeneration.set(gen);
    this.connection.set("CONNECTING");
    this.disposeSub();
    const from = this.lastAppliedSequence() ?? 0;
    const handle = this.realtime.subscribe(from, gen, {
      onEvent: (event, generation) => this.handleRealtimeEvent(event, generation),
      onDisconnect: (generation) => {
        if (generation !== this.subscriptionGeneration()) return;
        this.connection.set("DISCONNECTED");
      }
    });
    this.subDispose = handle.dispose;
    this.connection.set("LIVE");
  }
  handleRealtimeEvent(event, generation) {
    if (this.session() !== "AUTHENTICATED") return;
    if (generation !== this.subscriptionGeneration()) return;
    if (this.connection() === "RESYNC_REQUIRED") return;
    const last = this.lastAppliedSequence();
    if (last === null) return;
    if (this.appliedSequences.has(event.sequence) || event.sequence <= last) {
      return;
    }
    const expected = last + 1;
    if (event.sequence !== expected) {
      this.pendingGap.set({ expected, observed: event.sequence });
      this.connection.set("RESYNC_REQUIRED");
      return;
    }
    const current = this.snapshot();
    if (!current) return;
    this.snapshot.set({
      ...current,
      streamSequence: event.sequence,
      portfolioSummarySynthetic: event.payload.portfolioSummarySynthetic
    });
    this.lastAppliedSequence.set(event.sequence);
    this.appliedSequences.add(event.sequence);
  }
  markDisconnected() {
    this.realtime.disconnect();
    this.disposeSub();
    if (this.session() === "AUTHENTICATED") {
      this.connection.set("DISCONNECTED");
    }
  }
  beginReconnect() {
    if (this.session() !== "AUTHENTICATED") return;
    this.connection.set("RECONNECTING");
    this.beginRealtimeSubscribe();
  }
  logout() {
    this.disposeSub();
    this.realtime.disconnect();
    this.session.set("LOGGED_OUT");
    this.connection.set("DISCONNECTED");
    this.snapshot.set(null);
    this.lastAppliedSequence.set(null);
    this.pendingGap.set(null);
    this.appliedSequences.clear();
    this.preference.set({ ...EMPTY_PREF });
    this.preferenceBaseline.set(EMPTY_PREF.effectiveValue);
    this.sensitiveCleared.set(true);
    this.subscriptionGeneration.update((g) => g + 1);
  }
  requestPreferenceOptimistic(mutationId, value) {
    if (this.session() !== "AUTHENTICATED") return;
    const current = this.preference();
    this.preferenceBaseline.set(current.effectiveValue);
    this.preference.set({ effectiveValue: value, pendingMutationId: mutationId });
  }
  acceptPreference(mutationId) {
    const p = this.preference();
    if (p.pendingMutationId !== mutationId) return;
    this.preference.set({ effectiveValue: p.effectiveValue });
    this.preferenceBaseline.set(p.effectiveValue);
  }
  rejectPreference(mutationId) {
    const p = this.preference();
    if (p.pendingMutationId !== mutationId) return;
    this.preference.set({ effectiveValue: this.preferenceBaseline() });
  }
  /** Forbidden: no browser persistence APIs for sensitive state. */
  get storageApiTouchCount() {
    return 0;
  }
  disposeSub() {
    if (this.subDispose) {
      this.subDispose();
      this.subDispose = null;
    }
  }
};
export {
  SignalsFeatureStore
};
